//
//  AppDelegate.swift
//  Shortcut
//
//  Created by jonnyb on 9/22/17.
//  Copyright © 2017 jonnyb. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        let oceanShortcut = UIMutableApplicationShortcutItem(type: "\(String(describing: Bundle.main.bundleIdentifier)).ocean", localizedTitle: "Ocean", localizedSubtitle: nil, icon: UIApplicationShortcutIcon.init(templateImageName: "OceanShort"), userInfo: nil)
        application.shortcutItems = [oceanShortcut]
        
        return true
    }
    
    enum ShortcutType : String {
        case mountains = "mountains"
        case space = "space"
        case ocean = "ocean"
    }

    func application(_ application: UIApplication, performActionFor shortcutItem: UIApplicationShortcutItem, completionHandler: @escaping (Bool) -> Void) {
        
        if let type = shortcutItem.type.components(separatedBy: ".").last {
            
            let navVc = window?.rootViewController as! UITabBarController
            
            switch type {
            case ShortcutType.space.rawValue:
                navVc.selectedIndex = 1
                completionHandler(true)
            case ShortcutType.ocean.rawValue:
                navVc.selectedIndex = 2
            default:
                navVc.selectedIndex = 0
                completionHandler(true)
            }
        }
        completionHandler(false)
    }
}

