//
//  MountainsVC.swift
//  Shortcut
//
//  Created by jonnyb on 9/22/17.
//  Copyright © 2017 jonnyb. All rights reserved.
//

import UIKit

class MountainsVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

